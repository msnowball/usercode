#include <iostream>

#include "HiggsCSandWidth.cc"

using namespace std;

int main()
{

  HiggsCSandWidth *myCSW = new HiggsCSandWidth();

 
  for(int i = 0; i < 1000; i++){

    cout << i << " " << "0 " << myCSW->HiggsWidth(0,i) << endl;

  }

  for(int i = 0; i < 1000; i++){

    cout << i << " " << "1 " << myCSW->HiggsWidth(1,i) << endl;

  }

  for(int i = 0; i < 1000; i++){

    cout << i << " " << "2 " << myCSW->HiggsWidth(2,i) << endl;

  }

  for(int i = 0; i < 1000; i++){

    cout << i << " " << "3 " << myCSW->HiggsWidth(3,i) << endl;

  }

  for(int i = 0; i < 1000; i++){

    cout << i << " " << "4 " << myCSW->HiggsWidth(4,i) << endl;

  }

  for(int i = 0; i < 1000; i++){

    cout << i << " " << "5 " << myCSW->HiggsWidth(5,i) << endl;

  }

  for(int i = 0; i < 1000; i++){

    cout << i << " " << "6 " << myCSW->HiggsWidth(6,i) << endl;

  }

  for(int i = 0; i < 1000; i++){

    cout << i << " " << "7 " << myCSW->HiggsWidth(7,i) << endl;

  }

  for(int i = 0; i < 1000; i++){

    cout << i << " " << "8 " << myCSW->HiggsWidth(8,i) << endl;

  }

  for(int i = 0; i < 1000; i++){

    cout << i << " " << "9 " << myCSW->HiggsWidth(9,i) << endl;

  }

  for(int i = 0; i < 1000; i++){

    cout << i << " " << "10 " << myCSW->HiggsWidth(10,i) << endl;

  }

  for(int i = 0; i < 1000; i++){

    cout << i << " " << "11 " << myCSW->HiggsWidth(11,i) << endl;

  }











  for(int j = 0; j < 1000; j++){

    cout << j << "  My gg2H CS:      " << myCSW->HiggsCS(0,j,7) << endl;

  }

  return 0;

}
